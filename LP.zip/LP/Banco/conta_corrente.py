from contas import Conta

class ContaCorrente(Conta):
    pass

cc = ContaCorrente()
cc.taxa = 10

from django.shortcuts import render
from django.http import request
from core.models import Curso

# Create your views here.

def index(request):
    contexto = {
        "cursos": Curso.objects.all(),
        "faculdade":"Faculdade Impacta",
        "usuario": "Yuri",
        "logado": True,
        "idade": 27

    }
    return render(request,"index.html", contexto)

def contato(request):
    return render(request,"contato.html")

def cursos(request):
    return render(request,"cursos.html")